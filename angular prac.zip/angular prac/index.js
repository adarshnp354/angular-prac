

www=true

function show(){
    this.www= !this.www
  //style="display: none;"
 let img=  document.getElementById("image");
    
if(img.style.display =="block"){
    img.style.display ="none"
}else{
    img.style.display ="block"
}
 
}

ARRAY =[
    {name:"ghfh"},
    {name:"hghg"},
    {name:"uyuyuy"}
]