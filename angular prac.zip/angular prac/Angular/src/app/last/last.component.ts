import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { FrstlstService } from '../frstlst.service'

@Component({
  selector: 'app-last',
  templateUrl: './last.component.html',
  styleUrls: ['./last.component.css']
})
export class LastComponent implements OnInit {


  dateo: any;
  constructor(private frstlastservice:FrstlstService,private frm:FormBuilder) { }

  ngOnInit(): void {

    this.dateo=this.frstlastservice.showTodayDate()
  }

  deta:FormGroup=this.frm.group({
    id:[null],
    user:[null],
    view:[null],
    empty:[null]
  })

  abc:any=[]

  test:any

  sub(){
    if(this.deta.value.id==null){

      this.abc.push(this.deta.value);

    }else{

      this.abc[this.deta.value.id]=this.deta.value

    }


      this.deta.reset()
  }

  dan(i: any){
    this.abc.splice(i,1)

  }


  war(g: any,i: any){
    console.log(i);

    this.deta.patchValue({
      id:i,
      user:g.user,
      view:g.view,
      empty:g.empty
    })
  }

}
