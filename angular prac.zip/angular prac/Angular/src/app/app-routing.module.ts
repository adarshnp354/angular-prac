import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FirstComponent } from './first/first.component';
import { HomeComponent } from './home/home.component';
import { LastComponent } from './last/last.component';
import { AbcComponent } from './new/abc/abc.component';
import { XyzComponent } from './new/xyz/xyz.component';
import { SearchComponent } from './search/search.component';
import { SecondComponent } from './second/second.component';

const routes: Routes = [
  {path:"first",component:FirstComponent},
  {path:"second",component:SecondComponent},
  {path:"new",component:LastComponent},
  {path:"",component:HomeComponent},
  {path:"abc",component:AbcComponent},
  {path:"xyz",component:XyzComponent},
  {path:"search",component:SearchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
