import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';


import { Observable } from 'rxjs';
import { debounceTime, distinctUntilChanged, map, filter } from 'rxjs/operators';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor(private htt: HttpClient) { }

  ngOnInit(): void {
    this.data()
  }


  test:any = []
  public model: any;

  data() {
    this.htt.get("https://jsonplaceholder.typicode.com/users")
      .subscribe(
        (res) => {
          // console.log(res);

          this.test=res
        },
        (err) => {
          console.log(err);
        }
      )
  }


  // first ledger auto search //
  // formatter = (item: any) => item.name;
  // search = (text$: Observable<string>) => text$.pipe(
  //   debounceTime(200),
  //   distinctUntilChanged(),
  //   filter(term => term.length >= 1),
  //   map(term => this.test_Array.filter((item: any) => new RegExp(term, 'mi').test(item.name)).slice(0, 10))
  // )


  formatter = (item:any) => item.name;

  search = (text$: Observable<string>) => text$.pipe(
    debounceTime(200),
    distinctUntilChanged(),
    filter(term => term.length >= 1),
    map(term => this.test.filter((item:any) => new RegExp(term, 'mi').test(item.name)).slice(0, 10))
  )

}

