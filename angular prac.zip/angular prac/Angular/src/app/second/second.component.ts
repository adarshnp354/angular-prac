import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { FrstlstService } from '../frstlst.service';

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css']
})
export class SecondComponent implements OnInit {

  date:any;

  constructor(private http: HttpClient,private router:Router,private frstlast : FrstlstService,private fb:FormBuilder) { }

  ngOnInit(): void {
    this.date=this.frstlast.showTodayDate()
    this.test()
  }

USER:any=[]

form:FormGroup=this.fb.group({
  id:[null],
  name:[null],
  email:[null],
  street:[null]
})

  test(){
    this.http.get("https://jsonplaceholder.typicode.com/users")
  .subscribe(
    (res) => {
      // console.log(res);
      this.USER=res
    },
    (err) => {
      console.log(err.message);
    }
  );
  }

  edit(us: any,i: any){
    console.log("edit clicked");

    this.form.patchValue({
      id:i,
      name:us.name,
      email:us.email,
      street:us.street
    })

    // console.log(this.form.value.street);


    // console.log(i);


  }

  dlt(i: any){
    // console.log("deleted");
    if(confirm("do u want to delete?")){
      this.USER.splice(i,1)
    }else{
      this.router.navigate(['second'])
    }

  }

  change(){
    if(this.form.value.id!=null){
      this.USER[this.form.value.id]=(this.form.value)
    }else{
      this.USER.push(this.form.value)
    }

    this.form.reset()
    console.log(this.form.value.street);

  }

}
