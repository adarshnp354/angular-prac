import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FrstlstService } from '../frstlst.service';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {


  constructor(private fb: FormBuilder,private router: Router,private frstlast:FrstlstService) { }


  ngOnInit(): void {
  }


  signupForm: FormGroup = this.fb.group({
    user_id: [null],
    user_name: [null],
    user_email: [null],
    user_address: [null],
    user_laddress: [null],
    user_city: [null],
    user_state:[null]
  })


  ins:any=[];

  onSubmit(){

    if(this.signupForm.value.user_id==null){

      // console.log(this.signupForm.value);
      this.ins.push(this.signupForm.value)
      // console.log(this.ins);
      // console.log(this.signupForm.value.user_id);


    }else{

      this.ins[this.signupForm.value.user_id]=this.signupForm.value
      // console.log(this.signupForm.value.user_id );

    }


    this.signupForm.reset()
    // this.router.navigate(['home'])
  }

  edt(wr: any,i:any){
    // console.log(wr);


    this.signupForm.patchValue({
      user_id:i,
      user_name: wr.user_name,
      user_email:wr.user_email,
      user_address:wr.user_address,
      user_laddress:wr.user_laddress,
      user_city:wr.user_city,
      user_state:wr.user_state
    })
  }

  del(i:any){


   if(confirm("do u want to delete??")){
    this.ins.splice(i,1)
   }else{
     this.router.navigate(['first'])
   }



    // alert('delete clicked')
  }

}




