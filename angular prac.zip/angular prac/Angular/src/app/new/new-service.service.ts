import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class NewServiceService {

  constructor(private fb:FormBuilder) { }

  arr:any=[]

  newForm: FormGroup = this.fb.group({
    input_id:[null],
    input_name:[null],
    input_addr:[null],
    input_mail:[null]
  })



}
