import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NewServiceService } from '../new-service.service';

@Component({
  selector: 'app-abc',
  templateUrl: './abc.component.html',
  styleUrls: ['./abc.component.css']
})
export class AbcComponent implements OnInit {

  constructor(public compo:NewServiceService,private router:Router) { }

  ngOnInit(): void {

  }



  reg(){
    if(this.compo.newForm.value.input_id==null){

      // console.log(this.compo.newForm.value);
      this.compo.arr.push(this.compo.newForm.value)
      // console.log(this.compo.arr);

    }else{

      this.compo.arr[this.compo.newForm.value.input_id]=this.compo.newForm.value

      // console.log( this.compo.arr[this.compo.newForm.value.input_id]);

    }

    this.router.navigate(['xyz'])
    this.compo.newForm.reset()


  }



}
