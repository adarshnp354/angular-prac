import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NewServiceService } from '../new-service.service';

@Component({
  selector: 'app-xyz',
  templateUrl: './xyz.component.html',
  styleUrls: ['./xyz.component.css']
})
export class XyzComponent implements OnInit {

  constructor(public compo:NewServiceService,private router:Router) { }



  ngOnInit(): void {

    // console.log(this.data);
  }

  del(i: any){
    // console.log(i);
    if(confirm("Do You Want To Delete??")){
      this.compo.arr.splice(i,1)
    }else{
      this.router.navigate(['xyz'])
    }

  }

  edt(kk: any,i: any){
    // console.log(kk);



    this.compo.newForm.patchValue({
      input_id:i,
      input_name:kk.input_name,
      input_mail:kk.input_mail,
      input_addr:kk.input_addr
    })
    // console.log(this.compo.newForm.value);

    this.router.navigate(['abc'])
  }

  bck(){
    this.router.navigate(['abc'])
  }

}
