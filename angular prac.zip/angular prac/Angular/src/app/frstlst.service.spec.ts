import { TestBed } from '@angular/core/testing';

import { FrstlstService } from './frstlst.service';

describe('FrstlstService', () => {
  let service: FrstlstService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FrstlstService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
